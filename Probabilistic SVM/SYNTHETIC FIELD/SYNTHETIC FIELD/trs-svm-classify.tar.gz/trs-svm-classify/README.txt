Files:

classerror.ps  Plot of classification error (fraction of misclassified
               grid points) against sampling density (fraction of grid
               points sampled)

trs0003refmap.png  Bilevel image giving reference classificatio of
                   grid points

trs0003class-{n}.png  SVM based classification for n sample points

trs0003samples-{n}.txt  Sample points selected for n size sample
